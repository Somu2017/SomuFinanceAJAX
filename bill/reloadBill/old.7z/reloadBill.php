<?php 
	session_id("reloadBill");
	session_start();

	if(!empty($_POST)&&($_POST['action']=='reloadBill')) // Deletes an item from the DB
	{
		$billDate = $_POST['billDate'];
		$bill_no = $_POST['billNo'];

		$_SESSION['billDate'] = $billDate;
		$_SESSION['bill_no'] = $bill_no;
		header("Location: ../oldBill/");
	}
?>